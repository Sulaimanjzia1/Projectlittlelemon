# Little Lemon Booking System
The Little Lemon booking system is a project designed to help users manage and book appointments for their business. This project was created as part of the Meta Backend Developer Certificate program.

# Screenshots
## Screenshot 1: Main Page
![Main Page](img/Screenshot_2023-02-12_at_8.18.38_AM.png)
Main page of the website.

## Screenshot 2: Booking Page
![Booking Page](img/Screenshot_2023-02-12_at_8.18.47_AM.png)
This is the main booking page where users can view available appointments and make a reservation.

## Screenshot 3: Reservations Page
![Appointment Management](img/Screenshot_2023-02-12_at_8.18.59_AM.png)
This is the reservations page where users can view all reservations.








