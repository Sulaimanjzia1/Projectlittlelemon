#!/bin/sh

for file in *\ *; do
  mv "$file" "${file// /_}"
done
