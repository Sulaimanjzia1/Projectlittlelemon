import java.util.Random;   // Needed for the Random class

/**
   This class simulates rolling a pair of dice 10,000 times
   and counts the number of times doubles of are rolled for
   each different pair of doubles.
*/

public class DiceSimulation
{
   public static void main(String[] args)
   {
      final int NUMBER = 10000;  // Number of dice rolls

      // A random number generator used in
      // simulating the rolling of dice
      Random generator = new Random();

      int die1Value;       // Value of the first die
      int die2Value;       // Value of the second die
      int count = 0;       // Total number of dice rolls
      int snakeEyes = 0;   // Number of snake eyes rolls
      int twos = 0;        // Number of double two rolls
      int threes = 0;      // Number of double three rolls
      int fours = 0;       // Number of double four rolls
      int fives = 0;       // Number of double five rolls
      int sixes = 0;       // Number of double six rolls

      // TASK #1 Enter your code for the algorithm here
     
    	  
      while (count < NUMBER) {
  
      // "roll of the dice (picking a number 1-6)
      die1Value = generator.nextInt(6)+1;				//+1 makes it so it starts from 1 and generates between 1-6
      //System.out.println("You rolled:" + die1Value);   //random number generator to roll for value of die 1
          
      die2Value = generator.nextInt(6)+1;				//+1 makes it so it starts from 1 and generates between 1-6
           

      if (die1Value == 1 && die2Value ==1) {     //++ means to increment 
    	  snakeEyes++;
      }else if (die1Value == 2 && die2Value == 2) {  //++ increments of time 2 was rolled
       twos++;
   	  }else if (die1Value == 3 && die2Value == 3) {  // ++ increments number of times 3 was rolled
       threes++;
   	  }else if (die1Value == 4 && die2Value == 4) {  // ++ increments number of times 4 was rolled
       fours++;
   	  }else if (die1Value == 5 && die2Value == 5) {   // ++ increments number of times 5 was rolled
       fives++;
   	  }else if (die1Value == 6 && die2Value == 6) { // ++ increments number of times 6 was rolled
       sixes++;
   	  }
          
      
      count++;  // Increments the number of times dice were rolled
      
     } 
      
      
      
      // Display the results
      System.out.println ("You rolled snake eyes " +
                          snakeEyes + " out of " +
                          count + " rolls.");
      System.out.println ("You rolled double twos " +
                          twos + " out of " + count +
                          " rolls.");
      System.out.println ("You rolled double threes " +
                          threes + " out of " + count +
                          " rolls.");
      System.out.println ("You rolled double fours " +
                          fours + " out of " + count +
                          " rolls.");
      System.out.println ("You rolled double fives " +
                          fives + " out of " + count +
                          " rolls.");
      System.out.println ("You rolled double sixes " +
                          sixes + " out of " + count +
                          " rolls.");
      
   }
}