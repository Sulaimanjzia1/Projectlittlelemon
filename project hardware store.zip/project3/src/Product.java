
	abstract class Product {													//abstract class named Product
    private static int numberOfProducts = 0;									// private static variable that keeps the total number of products created.initialized to 0.
    
    // introduction of 4 instance variables
    
    protected int id;															//id, an integer - represents the ID of the product
    protected String name;														//name, a String - represents the name of the product.
    protected double regularPrice;												//regularPrice, a double - represents the regular price of the product.
    protected char type;														//type, a char - represents the type of the product

    public Product(int id, String name, double regularPrice, char type) {		//intorduction of 4 parameters char, Double, String and integer
    this.id = id;
    this.name = name;
    this.regularPrice = regularPrice;
    this.type = type;
    numberOfProducts++;															//incrementation of the number of products
    }

    public static int getNumberOfProducts() {									//static method that allows you to retrieve the number of products created
    return numberOfProducts;													//it returns it here
    }

    public abstract double total(int units);									//This is an abstract method, meaning it is declared but not implemented in the class. 

    @Override
    public String toString() {													//The toString method is overridden to provide a custom string of a Product object.
        return "ID: " + id + "Product: " + name + ", Regular Price: $" + regularPrice + ", Type: " + type;	//returns it in this format ID then name then regular price and type
    }}
