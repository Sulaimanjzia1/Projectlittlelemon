
		class BProduct extends Product {							//defines a class "BProduct" that extends another class "Product"
		public BProduct(String name, double regularPrice) {			//the constructor for the BProduct class.takes two parameters a string and a double
		super(1, name, regularPrice, 'B');							// "1" "name" "regularPrice" "B" are all parameters passed to super to 
		}															//initialize the inherited fields of the Product class

    																//This code overrides the total method, calculates the total cost of number of units based on conditions
    	@Override														
    	public double total(int units) {
        if (units < 100) {											//If number is less than 100, the total cost is calculated as the regular price multiplied by the number of units.
            return regularPrice * units;
        } else if (units < 500) {
            return 0.95 * regularPrice * units;						//If number is between 100 and 500, the total cost is calculated as 95% of the regular price multiplied by the number of units
        } else if (units < 1500) {
            return 0.85 * regularPrice * units;						//If number is between 500 and 1500, the total cost is calculated as 85% of the regular price multiplied by the number of units
        } else {
            return 0.75 * regularPrice * units;						//If number is 1500 or more, the total cost is calculated as 75% of the regular price multiplied by the number of units.
        }}}