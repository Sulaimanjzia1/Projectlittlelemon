/* 	Course: ICSI/IECE 201
 	Semester: Fall 2023
 	Lab Section: Wednesday 10:35AM
 	Name: Sulaiman Zia
	Net ID: SZ694815
	Email: szia@albany.edu
*/

//import of java functionalities and tools to be used throughout the code
//import of java utilities and the java io Input/output functionalities
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

	//This program is an advanced version of the previous project which was the hardware store
	//in this program you can order items for your hardware store and based on the amount of your order
	//there will be a discount amount depending on the quantity ordered
	//you can also view your inventory and review your order in this program

	public class P3Driver_SZ694815 {

		
    public static void main(String[] args) {											 // the main method is started here
    int maxItems = 100, itemCount = 0;													 // the maximum items 'int' is set to 100 and the item count also 'int' is initialized at 0
    Scanner scanner = new Scanner(System.in);											 // use of the scanner as an input tool (keyboard)

    Item_SZ694815[] inventory = new Item_SZ694815[maxItems];							 ////declares an array named "inventory" of type "Item_SZ694815
    ArrayList<Order> orders = new ArrayList<>();

    // this part's function is to Load all the items which stored in the .txt file (sample data.txt) 
    // using the try and catch method as used in the previous project
    // I used the try and catch methods from my outside knowledge which is why i had the java.io.ioexpection functionality i put the code for the BufferedReader in the try block 
    // because the statement allows you to define a block of code to be tested for errors while it is being executed. the try block is a block of code 
    // in which exceptions can occur, it's used to enclose the code that might throw an exception and afterwards i have included a catch method 
    // which handles the exception that occurs in the associated try block


    try ( BufferedReader bReader = new BufferedReader(new FileReader("sample data.txt"))){//setting a new buffered reader name bReader for reading the inventory.txt file
    String line;
    while ((line = bReader.readLine()) != null) {                    					 //sets up a while loop that reads lines from the file using the BufferedReader. It continues to loop as long as
    																					 //there are more lines to read and doesn't return null
    String[] parts = line.split(",");												     //this  splits the line into an array of strings based on comma ","
    if (parts.length == 4) {															 //this if statement checks if the array 'parts' contains exactly 4
    int id = Integer.parseInt(parts[0]);
    String name = parts[1]; 															 //These are individual pieces of data from the 'parts' array The first element parts[0] is supposed to be a name, a string)
    double price = Double.parseDouble(parts[2]);					                     //the second data, parts[1] is supposed to be a price a floating-point number using double data type
    char type = parts[3].charAt(0);								       	 				 //and the third data, parts[3] is supposed to be an amount using the int data type
    Item_SZ694815 item = new Item_SZ694815(id, name, price, type);						 //this creates an instance of the Item_SZ694815 class using the extracted data from the txt file using name, price, and amount
    inventory[itemCount] = item;														 //this adds the Item_SZ694815 object to an array named "inventory."
    itemCount++;																		 //incrementing the itemCount using ++
    }}}
    
    //here I have ended the try method ending it with the catch method to end the try method loop
    catch (IOException e) {																 //this line specifies that this catch block is to catch and handle exceptions of type IOException. If it occurs within the try block, 
    e.printStackTrace();
    }

    
    //this part of the code is a while loop that prints out different options based on the character  chosen
    //so while I is chosen it will show Inventory and so on...
    //I also used the switch method to switch the characters typed into functions performed
    while (true) {																		 // so the while loop starts here and when true it prints the following:
    System.out.print("""
                               (I)Inventory												
                               (O)Order
                               (R)Review
                               (E)Exit
                               """);

    System.out.print("Your choice: ");													 //this is to prompt the user to make a choice based on the options given
    char choice = scanner.next().charAt(0);												 //here is what allows them to enter a choice from the scanner(keyboard)
    											
    																					 //I used the switch method to make it easier for a character to have a function
    																					 //each letter type will have a different function and the default is set to 'invalid choice'
    																					 // so this way any other letter is wrong and it will loop back for them to type the right one
    
    switch (choice) {																	 //so if they pick 'i' it corresponds to inventory so it will show the inventory
    case 'i' ->
    showInventory(inventory, itemCount);

    case 'o' ->																			 //if they pick 'o' it corresponds to order so they will be prompt to type 
    createOrder(inventory, itemCount, orders);											 //what they want to order and they can type the name

    case 'r' ->																			 //if they pick 'r' it corresponds to review so they will be able to review
    reviewOrders(orders);																 //the order they made

    case 'e' -> {																		 //if they pick 'e' it corresponds to exit so when their task is done, they can
    saveOrdersToFile(orders);															 //exit the program by using 'e'
    System.exit(0);
    }

    default ->																			 //default set to invalid choice so they are looped to enter the right letter
    System.out.println("\nInvalid choice\n");
    }}}

    
    
    
    //This method is used to show the complete inventory when the user chooses i
    public static void showInventory(Item_SZ694815[] inventory, int itemCount) {		 //This is the method signature, public static method named showInventory and takes two parameters:    																									//inventory which is an array of SZ694815 and itemCount        
    System.out.println("The inventory: ");												 //inventory which is an array of SZ694815 and itemCount

    for (int i = 0; i < itemCount; i++) { 											 	 //use of for loop that iterates over the items in the inventory array and runs as long as i is less than itemCount
    Item_SZ694815 item = inventory[i];													 //this retrieves an item from the inventory array at index i and assigns it to the item																//this print line prints the item's ID by adding 1 to i
    System.out.println(item.toString());												 //this print line prints the rest of the item's by calling the toString method on the Item_SZ694815 object. 
    }
    System.out.println("");}

    
    
    //this body of the code is what helps the user to create an order when they pick 'o'
    private static void createOrder(Item_SZ694815[] inventory, int itemCount, ArrayList<Order> orders) {
    double total = 0;																	 //total is set to a double data type and initialized at 0
    Scanner scanner = new Scanner(System.in);											 //again the use of scanner keyboard to input data

    System.out.println("Enter product name: ");											 //this line prompts the user to write the name
    String productName = scanner.nextLine();											 //and this line allows the scanner(keyboard) to be used
        
    Item_SZ694815 selectedProduct = findProductByName(inventory, itemCount, productName);
    
    //here is have made an if statement or an if loop for the program to be able to order what the user wants based 
    //off of the inventory but when the item name doesn't match the inventory it loops the user back giving them an error
    //of invalid product
    if (selectedProduct != null) {														 //If selectedProduct is not null, means a product has been selected
    System.out.println("Enter quantity: ");												 //this line prompts the user to enter the quantity of they product
    int quantity = scanner.nextInt();													 //this allows the usage of keyboard for input
    System.out.println("Enter the order date (dd/mm/yyyy): ");							 //this prints the date in the day/month/year format
    scanner.nextLine();																	 //skip a line here
    String orderDateStr = scanner.nextLine();											 //here it uses a Scanner to read user input for quantity and order date
    Date orderDate = new Date(orderDateStr);
    System.out.println("");
            
    int itemID = selectedProduct.getId();												 //itemID is set as an integer data type
    String itemName = selectedProduct.getName();										 //itemName is set as a string data type
    char itemType = selectedProduct.getType();											 //itemtype is set as a char data type which will be switched based on what they chose
    double itemPrice = selectedProduct.getPrice();										 //itemPrice is set as a double data type
            
    Product product = new Product(itemID, itemName, itemPrice, itemType) {				 //Creates a Product object based on the above information.

    @Override
    public double total(int units) {													 //Overrides the total method, but the overridden method throws an UnsupportedOperationException
    throw new UnsupportedOperationException("Not supported yet."); 
    }};
    
    // again the use of the switch method to have the characters typed connect to a function
    switch (itemType) {															
    case 'R' -> {																		 // Inherits from the Product class.
    RProduct rProduct = new RProduct(itemName, itemPrice);								 //Overrides the total method to calculate the cost simply as the regular price
    total = rProduct.total(quantity);
    }
    case 'B' -> {																		 //when typed 'B' Inherits from the Product class.
    BProduct bProduct = new BProduct(itemName, itemPrice);								 //Overrides the total method to calculate the cost based on the conditions related to the number of units.
    total = bProduct.total(quantity);
    }
    case 'S' -> {																		 //when typed 's' it is also inherited from the product class
    SProduct sProduct = new SProduct(itemName, itemPrice);								 //Overrides the total method to calculate the cost based on conditions related to the current month
    total = sProduct.total(quantity);
    }
    default -> {
    }}
    Order order = new Order(product, quantity, orderDate, total);						 //Creates an Order object using the selected product, quantity, order date, and total.
    orders.add(order);																	 //and this line Adds the order to the collection
    } else {																			 //but if If selectedProduct is null, it means the product was not found in the inventory.
    System.out.println("Product not found in the inventory.\n");						 //Prints a message indicating that the product was not found.
    }}

    
    
    
    //This method searches for a product in an array of Item_SZ694815 objects based on the product name.
    //takes three parameters inventory, itemCount, productName
    private static Item_SZ694815 findProductByName(Item_SZ694815[] inventory, int itemCount, String productName) {

    for (int i = 0; i < itemCount; i++) { 											 	 //use of for loop that iterates over the items in the inventory array and runs as long as i is less than itemCount
    Item_SZ694815 item = inventory[i];											  		 //this retrieves an item from the inventory array at index i and assigns it to the item																//this print line prints the item's ID by adding 1 to i
    if (item.getName().equalsIgnoreCase(productName)) {		 					  		 //this part help the code ignore upper or lower case words when typing the name
    return item;																		 //if the name of the item matches a product name it returns the item
    }																					 
    }
    return null;																		 //If no match is found after iterating through the entire inventory, it returns null
    }

    private static void reviewOrders(ArrayList<Order> orders) {							 //This method is for reviewing and printing the details of orders stored in an ArrayList of Order objects.
    for (Order order : orders) {														 //used a for loop to iterate over each Order object in the orders list
    System.out.println(order);															 //For each Order, it prints the details by using the toString method on the Order object.
    }}
    
    
    
    
    private static void saveOrdersToFile(ArrayList<Order> orders) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("orders.txt"))) {	 // creates a BufferedWriter that wraps a FileWriter. The FileWriter is set to write to a file named "orders.txt."

    // Iterate through the orders and write each order to the file
    for (Order order : orders) {														 //used a for loop to iterate over each Order object in the orders list.
    writer.write(order.toString());														 //For each order, it writes the string representation of the order through order.toString to the file using the BufferedWriter
    writer.newLine(); 																	 //this adds a newline to separate orders
    }

    System.out.println("Your order is saved. Goodbye!\n");								 //prints a success message to the console to show order is saved
    } 
    catch (IOException e) {																 //here If an IOException occurs during the file writing process, an error message is printed to the standard error stream
    System.err.println("Error writing orders to file: " + e.getMessage());
	}}}
