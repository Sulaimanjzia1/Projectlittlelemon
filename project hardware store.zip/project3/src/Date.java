// Create a new Date class
class Date {
    private int day;														// Day Variable set as int
    private int month;													    // month Variable set as int
    private int year;														// year Variable set as int

    public Date(String dateString) {										//constructor for the Date class takes a String parameter dateString
    String[] dateParts = dateString.split("/");								//splits the input string using the "/" creating an array of 'dateParts'
    if (dateParts.length == 3) {											// then checks if there are exactly three parts (day, month, and year).
    try {
    this.day = Integer.parseInt(dateParts[0]);								//If there are three parts, it attempts to parse
    this.month = Integer.parseInt(dateParts[1]);							//each part into integers (day, month, and year) 
    this.year = Integer.parseInt(dateParts[2]);
    } 
    catch (NumberFormatException e) {										// If any parsing fails  a NumberFormatException is caught
    System.out.println("Invalid date format. Please use dd/mm/yyyy.\n");}	//and an error message is printed
    // Handle or throw exception as needed
    } 
    else {																	//If the input string does not have three parts
    System.out.println("Invalid date format. Please use dd/mm/yyyy.\n");}	//an error message is also printed
    // Handle or throw exception as needed
    }
    

    @Override
    public String toString() {												//The toString method is overridden to provide a string representation of the Date 
    return day + "/" + month + "/" + year;									//It returns a string in the format "dd/mm/yyyy" based on the values stored
    }}
