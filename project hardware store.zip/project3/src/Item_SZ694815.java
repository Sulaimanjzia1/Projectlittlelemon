
public class Item_SZ694815 {
    int id;																//here the ID is set as a int variable
    String name;														//here name is a String variable
    double price;														//price is set to a double data type
    char type;															//and the type of the items in the inventory is set to an char data type
    
    public Item_SZ694815(int id, String name, double price, char type) {//here is the class constructor. It's used to create objects. and takes  parameters: ID, name, price, and type.
     this.id = id;
     this.name = name;												
     this.price = price;
     this.type = type;
    }
    
    public int getId() {												//here is the getter methods to retrieve the ID
        return id;														//here it returns the ID after it gets/finds it 
    }
    
    public String getName() {											//here is the getter methods to retrieve the name, price and quantity
        return name;													//here it returns the name after it gets/finds it 
    }
    
    public double getPrice() {											//here it gets/finds the price - named getPrice 
        return price;													//and returns the price after it finds it
    }
    
    public char getType() {												//here it gets/finds the type - named getType
        return type;													//and returns the type after it finds it
    }
    
    @Override															//here I used the override function from java's object class
    public String toString() {											//this is the toString method, which is an override of the standard/original toString method
    return id + "\t" + name + "\t\t" + price + "  \t" + type;			//so when it retrieves and finds the data it separates it by tabs and spaces for a clear visualization and understanding
    }}
