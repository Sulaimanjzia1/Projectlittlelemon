
	class Order {																	//declares the Order class with four private instance variables
    private final Product product;													//product is one of the instance variables
    private final int quantity;														//quantity is also one of the instance variable set to int
    private final Date orderDate;													//orderDate is a instance variable 
    private final double total; 													//and finally total which is set to a double data type

    public Order(Product product, int quantity, Date orderDate, double total) {		//new parameters product, integer, date and double
    this.product = product;
    this.quantity = quantity;
    this.orderDate = orderDate;
    this.total = total;
    }

    @Override
    public String toString() {														//toString method is overridden to give a string representation of the Order object.
        return "\n\nDate: " + orderDate												//and this function returns the date and the order information in the given Format:
                + "\n+---+-----------------+------+----+"
                + "\n|ID |Name |Price |Type|"
                + "\n+---+-----------------+------+----+"
                + "\n" + product.id + "\t" + product.name + "\t" + product.regularPrice + "\t" + product.type
                + "\n+---+-----------------+------+----+"
                + "\nQTY: " + quantity 
                + "\nTotal: " + total + "\n";
    }}
