
	class SProduct extends Product {						// Sproduct class extends the product class
    public SProduct(String name, double regularPrice) {		// the Sproduct takes in two parameter string and double
    super(1, name, regularPrice, 'S');						//here parameters passed to super and used to initialize the inherited fields of the Product class
    }

    @Override												//use of override again
    public double total(int units) {						//introduction of total object
    // Assuming November, December, and January are considered as the season
    int currentMonth = 1; // For simplicity, let's assume January (1 is January in Java Calendar)
    if (currentMonth >= 11 && currentMonth <= 1) { //use of the If Statement to loop the discount if month is > or = to 11 and if its < or = 1
    return 0.6 * regularPrice * units; //this represents 40% discount during the season
    }else {								// use of else statement to return the original price if it doesn't meet the conditions
    return regularPrice * units;		
    }}}