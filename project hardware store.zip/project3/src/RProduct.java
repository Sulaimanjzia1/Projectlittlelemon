
class RProduct extends Product {							//this class extends the product class
    public RProduct(String name, double regularPrice) {		// holds two parameter string and double
    super(1, name, regularPrice, 'R');				    	//here parameters passed to super and used to initialize the inherited fields of the Product class.
    }

    @Override												//This code is over riding the total method from its superclass Product
    public double total(int units) {						//declares a method named total that takes an integer parameter
    return regularPrice * units;						    //this code returns the regularprice multiplied by units
    }}